-- Employee360 Database Schema
-- Phase 2: Core tables for Employee Management System

CREATE DATABASE IF NOT EXISTS employee360;
USE employee360;

-- --------------------------------------------------------
-- Table: users
-- For application/admin login later.
-- --------------------------------------------------------

CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(100) UNIQUE NOT NULL,
    email VARCHAR(150) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    role VARCHAR(50) DEFAULT 'admin',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------
-- Table: departments
-- Departments within the organization.
-- --------------------------------------------------------

CREATE TABLE IF NOT EXISTS departments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) UNIQUE NOT NULL,
    description TEXT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------
-- Table: employees
-- Employee records.
-- --------------------------------------------------------

CREATE TABLE IF NOT EXISTS employees (
    id INT AUTO_INCREMENT PRIMARY KEY,
    employee_id VARCHAR(50) UNIQUE NOT NULL,
    first_name VARCHAR(100) NOT NULL,
    last_name VARCHAR(100) NOT NULL,
    email VARCHAR(150) UNIQUE NOT NULL,
    phone VARCHAR(20) NULL,
    gender VARCHAR(20) NULL,
    date_of_birth DATE NULL,
    address TEXT NULL,
    position VARCHAR(100) NULL,
    salary DECIMAL(10,2) NULL,
    hire_date DATE NULL,
    department_id INT NULL,
    status VARCHAR(30) DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (department_id) REFERENCES departments(id)
        ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Index on department_id for faster lookups
CREATE INDEX idx_employees_department_id ON employees(department_id);

-- --------------------------------------------------------
-- Table: attendance
-- Attendance records for employees.
-- --------------------------------------------------------

CREATE TABLE IF NOT EXISTS attendance (
    id INT AUTO_INCREMENT PRIMARY KEY,
    employee_id INT NOT NULL,
    date DATE NOT NULL,
    check_in TIME NULL,
    check_out TIME NULL,
    status VARCHAR(30) DEFAULT 'present',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (employee_id) REFERENCES employees(id)
        ON DELETE CASCADE ON UPDATE CASCADE,
    UNIQUE KEY unique_employee_date (employee_id, date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Index on employee_id for faster lookups
CREATE INDEX idx_attendance_employee_id ON attendance(employee_id);

-- --------------------------------------------------------
-- Table: leaves
-- Leave requests for employees.
-- --------------------------------------------------------

CREATE TABLE IF NOT EXISTS leaves (
    id INT AUTO_INCREMENT PRIMARY KEY,
    employee_id INT NOT NULL,
    leave_type VARCHAR(50) NOT NULL,
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    reason TEXT NULL,
    status VARCHAR(30) DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (employee_id) REFERENCES employees(id)
        ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Index on employee_id for faster lookups
CREATE INDEX idx_leaves_employee_id ON leaves(employee_id);

-- --------------------------------------------------------
-- Sample data for development/testing
-- --------------------------------------------------------

-- Insert sample departments
INSERT IGNORE INTO departments (name, description) VALUES
('Human Resources', 'HR Department'),
('Engineering', 'Engineering Department'),
('Marketing', 'Marketing Department'),
('Finance', 'Finance Department'),
('Operations', 'Operations Department');

-- Insert sample employees
INSERT IGNORE INTO employees (employee_id, first_name, last_name, email, phone, gender, date_of_birth, address, position, salary, hire_date, department_id, status) VALUES
('EMP001', 'John', 'Doe', 'john.doe@company.com', '555-0101', 'Male', '1990-05-15', '123 Main St, City', 'Software Engineer', 75000.00, '2021-03-15', 2, 'active'),
('EMP002', 'Jane', 'Smith', 'jane.smith@company.com', '555-0202', 'Female', '1988-08-20', '456 Oak Ave, Town', 'HR Manager', 80000.00, '2020-01-10', 1, 'active'),
('EMP003', 'Michael', 'Johnson', 'michael.johnson@company.com', '555-0303', 'Male', '1992-12-10', '789 Pine Rd, Village', 'Data Analyst', 65000.00, '2022-06-01', 2, 'active'),
('EMP004', 'Emily', 'Davis', 'emily.davis@company.com', '555-0404', 'Female', '1991-03-25', '321 Elm St, City', 'Marketing Specialist', 60000.00, '2021-11-01', 3, 'active'),
('EMP005', 'David', 'Wilson', 'david.wilson@company.com', '555-0505', 'Male', '1989-07-30', '654 Maple Dr, Town', 'Financial Analyst', 70000.00, '2019-05-20', 4, 'active');

-- Insert sample attendance records
INSERT IGNORE INTO attendance (employee_id, date, check_in, check_out, status) VALUES
(1, '2024-01-15', '08:00:00', '17:00:00', 'present'),
(1, '2024-01-16', '08:15:00', '17:15:00', 'present'),
(2, '2024-01-15', '09:00:00', '18:00:00', 'present'),
(3, '2024-01-15', '08:30:00', '16:30:00', 'present'),
(4, '2024-01-15', '09:00:00', '17:00:00', 'present'),
(5, '2024-01-15', '08:00:00', '17:00:00', 'present');

-- Insert sample leave requests
INSERT IGNORE INTO leaves (employee_id, leave_type, start_date, end_date, reason, status) VALUES
(1, 'Annual', '2024-02-01', '2024-02-05', 'Vacation', 'approved'),
(2, 'Sick', '2024-02-10', '2024-02-12', 'Flu', 'approved'),
(3, 'Annual', '2024-03-15', '2024-03-19', 'Family trip', 'pending'),
(4, 'Sick', '2024-03-20', '2024-03-22', 'Fever', 'pending'),
(5, 'Annual', '2024-04-01', '2024-04-05', 'Holiday', 'pending');